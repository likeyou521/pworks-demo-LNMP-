<?php
require_once('pworks/mvc/action/BaseAction.class.php');

require_once dirname(__FILE__).'/Test.class.php';

class GetInfoAction extends BaseAction {
    
    public $id;
    public $name;

    public function execute() {

        $result = Test::getTest();

        if (empty($result)) {
            $this->addError('e10001','xxxx','ssss');
            return 'error';
        }

        $this->setData('result',['name'=>$this->name]);
        return 'succ';

    }
   
}
