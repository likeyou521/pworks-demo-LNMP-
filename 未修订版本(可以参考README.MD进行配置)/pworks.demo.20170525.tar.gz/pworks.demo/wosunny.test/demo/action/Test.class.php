<?php


class Test {

    static public function getTest() {

        return 'abc';
    }

}
